
import React from 'react';
import { productsList } from './Products';
import { ArrowLeft, ShieldCheck, Zap, Activity, Cpu, FileText, Share2, Network, ChevronRight } from 'lucide-react';

interface ProductDetailProps {
  productId: string;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ productId }) => {
  const product = productsList.find(p => p.id === productId);

  if (!product) {
    return (
      <div className="py-32 px-6 text-center animate-pulse">
        <h1 className="text-4xl font-bold text-white mb-4 font-mono tracking-tighter uppercase">404: RESOURCE_MISSING</h1>
        <p className="text-gray-500 mb-8 font-mono text-sm">THE REQUESTED ASSET ID [{productId?.toUpperCase()}] WAS NOT FOUND IN THE LOCAL DATABASE.</p>
        <a href="#/products" className="text-emerald-500 font-mono hover:underline flex items-center justify-center gap-2 tracking-widest uppercase">
          <ArrowLeft className="w-4 h-4" /> REBOOT_TO_INVENTORY
        </a>
      </div>
    );
  }

  return (
    <div className="py-12 md:py-24 px-6 animate-in fade-in slide-in-from-bottom duration-1000 relative">
      {/* Decorative Blueprint elements */}
      <div className="absolute top-0 right-0 w-64 h-64 border-r border-t border-emerald-500/10 -z-10 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto">
        {/* Navigation Breadcrumb */}
        <nav className="flex items-center gap-2 text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-12">
          <a href="#/" className="hover:text-emerald-500 transition-colors">COMMAND</a>
          <ChevronRight className="w-3 h-3" />
          <a href="#/products" className="hover:text-emerald-500 transition-colors">SYSTEMS</a>
          <ChevronRight className="w-3 h-3 text-emerald-500" />
          <span className="text-emerald-500">{product.id}</span>
        </nav>

        <a href="#/products" className="inline-flex items-center gap-2 text-emerald-500 font-mono text-xs mb-8 hover:text-emerald-400 transition-colors tracking-[0.3em] uppercase group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back_to_Systems_Catalog
        </a>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Visual Presentation Area */}
          <div className="space-y-8 lg:sticky lg:top-32">
            <div className="glass-panel p-2 rounded-[2.5rem] relative overflow-hidden group shadow-[0_0_80px_rgba(16,185,129,0.05)]">
              <div className="bg-gradient-to-br from-emerald-950/40 to-black rounded-[2.3rem] overflow-hidden aspect-square flex items-center justify-center relative">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-[2000ms]"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800";
                  }}
                />
                {/* Overlay Technical UI Elements */}
                <div className="absolute inset-0 pointer-events-none border-[1px] border-white/5 rounded-[2.3rem]"></div>
                <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full border border-emerald-500/30">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                   <span className="text-[8px] font-mono text-emerald-400 uppercase tracking-widest">Telemetry_Stream: ACTIVE</span>
                </div>
              </div>
              
              <div className="absolute bottom-8 right-8 flex flex-col gap-2">
                 <button className="w-12 h-12 glass-panel rounded-full flex items-center justify-center text-emerald-400 hover:bg-emerald-500 hover:text-white transition-all shadow-2xl border-white/10 group/share">
                   <Share2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
                 </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {[
                { icon: ShieldCheck, label: "Safety_SIL" },
                { icon: Zap, label: "Deterministic" },
                { icon: Network, label: "UNS_Ready" }
              ].map((item, i) => (
                <div key={i} className="glass-panel p-6 rounded-3xl flex flex-col items-center gap-3 group hover:border-emerald-500/40 transition-all duration-500">
                  <item.icon className="text-emerald-500 w-6 h-6 group-hover:scale-110 transition-transform" />
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-tighter">{item.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Technical Specifications & Content Section */}
          <div className="space-y-12">
            <div className="animate-in fade-in slide-in-from-right duration-700 delay-200">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-[10px] font-mono mb-6 uppercase tracking-widest shadow-inner">
                {product.brand} // SYSTEM_ADDR_{product.id.toUpperCase()}
              </div>
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-8 leading-[1.1] tracking-tight">
                {product.name}
              </h1>
              <div className="prose prose-invert max-w-none">
                <p className="text-xl text-gray-400 leading-relaxed font-light mb-8 italic border-l-2 border-emerald-500/30 pl-8">
                  {product.description}
                </p>
              </div>
            </div>

            <div className="space-y-6 animate-in fade-in slide-in-from-right duration-700 delay-300">
              <h3 className="text-emerald-500 font-mono text-[10px] tracking-[0.5em] uppercase border-b border-emerald-500/20 pb-4 flex items-center gap-3">
                <Cpu className="w-4 h-4" /> ARCHITECTURAL_SPECIFICATIONS
              </h3>
              <div className="grid gap-3">
                {Object.entries(product.specs).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center py-4 px-4 border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-emerald-500/20 transition-all rounded-2xl group">
                    <span className="text-gray-500 text-sm font-mono tracking-tight uppercase">{key}</span>
                    <span className="text-white font-mono text-sm group-hover:text-emerald-400 transition-colors font-bold">{value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-6 animate-in fade-in slide-in-from-right duration-700 delay-400">
              <a 
                href="#/contact" 
                className="flex-[2] px-8 py-5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl transition-all text-center shadow-[0_10px_30px_rgba(16,185,129,0.3)] flex items-center justify-center gap-3 group/cta tracking-widest uppercase text-xs"
              >
                REQUEST_ENGINEERING_AUDIT <Zap className="w-5 h-5 group-hover:animate-bounce" />
              </a>
              <button className="flex-1 px-8 py-5 glass-panel text-white font-bold rounded-2xl hover:bg-white/10 transition-all border-white/5 flex items-center justify-center gap-3 group/dl text-xs tracking-widest uppercase">
                DATASHEET <FileText className="w-5 h-5 group-hover:text-emerald-400" />
              </button>
            </div>

            <div className="p-8 bg-gradient-to-r from-emerald-950/40 to-transparent border border-emerald-500/20 rounded-[2.5rem] relative overflow-hidden group">
              <div className="absolute -right-12 -bottom-12 opacity-5 group-hover:opacity-10 transition-opacity">
                 <ShieldCheck size={160} className="text-emerald-500" />
              </div>
              <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-500" /> Operational Rigor Assurance
              </h4>
              <p className="text-gray-400 text-xs leading-relaxed max-w-md font-mono uppercase tracking-tighter">
                THIS COMPONENT IS VALIDATED FOR <span className="text-white">OT/IT CONVERGENCE</span> VIA THE <span className="text-emerald-500 font-bold">UNIFIED NAMESPACE (UNS)</span>. FULL DETERMINISTIC LOGIC VALIDATION IS PROVIDED BY OUR HYDERABAD CENTER OF EXCELLENCE.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
