
import React from 'react';
import { ShieldCheck, Target, Repeat, RefreshCw } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-32">
          <div>
            <h2 className="text-sky-500 font-mono text-sm tracking-[0.4em] mb-4">ENGINEERING_RIGOR</h2>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-8">Bridging Heritage with Autonomy</h1>
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              Based in the industrial hub of Hyderabad, SGA Industrial Automations has spent over a decade refining the intersection of mechanical reliability and digital intelligence.
            </p>
            <p className="text-gray-400 leading-relaxed">
              We advocate for <span className="text-white font-bold">Industry 5.0</span>: a paradigm shift where the efficiency of Industry 4.0 meets the human-centric focus of sustainable and resilient production. Our systems are not just automated; they are deterministic, secure, and future-ready.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="glass-panel p-6 rounded-2xl border-b-4 border-b-sky-500">
                <ShieldCheck className="text-sky-400 mb-4" />
                <h4 className="text-white font-bold">ISA-95</h4>
                <p className="text-xs text-gray-500 uppercase tracking-tighter">Standard Compliance</p>
              </div>
              <div className="glass-panel p-6 rounded-2xl">
                <Target className="text-emerald-400 mb-4" />
                <h4 className="text-white font-bold">SIL-3</h4>
                <p className="text-xs text-gray-500 uppercase tracking-tighter">Safety Integrity</p>
              </div>
            </div>
            <div className="space-y-4 mt-8">
              <div className="glass-panel p-6 rounded-2xl">
                <Repeat className="text-sky-400 mb-4" />
                <h4 className="text-white font-bold">99.9%</h4>
                <p className="text-xs text-gray-500 uppercase tracking-tighter">Logic Uptime</p>
              </div>
              <div className="glass-panel p-6 rounded-2xl border-t-4 border-t-sky-500">
                <RefreshCw className="text-sky-400 mb-4" />
                <h4 className="text-white font-bold">UNS</h4>
                <p className="text-xs text-gray-500 uppercase tracking-tighter">Unified Namespace</p>
              </div>
            </div>
          </div>
        </div>

        <section className="relative">
          <div className="text-center mb-16">
            <h2 className="text-sky-500 font-mono text-sm tracking-[0.4em] mb-4">OPERATIONAL_FRAMEWORK</h2>
            <h1 className="text-3xl md:text-5xl font-bold text-white">Lifecycle of Excellence</h1>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Audit", desc: "Rigorous onsite discovery of current OT/IT debt and infrastructure state." },
              { step: "02", title: "Architect", desc: "Modeling a Unified Namespace and selecting deterministic hardware." },
              { step: "03", title: "Deploy", desc: "Execution under ISO standards with zero-latency handovers." },
              { step: "04", title: "Advance", desc: "Continuous optimization through AI-driven predictive maintenance." }
            ].map((phase, i) => (
              <div key={i} className="relative group">
                <div className="text-6xl font-bold text-sky-900/20 absolute -top-10 left-0 group-hover:text-sky-500/20 transition-colors">
                  {phase.step}
                </div>
                <div className="pt-4">
                  <h3 className="text-xl font-bold text-white mb-4">{phase.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{phase.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;
