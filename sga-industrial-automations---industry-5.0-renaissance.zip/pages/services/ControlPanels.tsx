
import React from 'react';
import { Cpu, ShieldCheck, Zap, Activity, Layers, PenTool, ThermometerSnowflake, Ruler, ArrowRight } from 'lucide-react';

const ControlPanels: React.FC = () => {
  const panelFeatures = [
    { title: "PLC/DCS Control Panels", icon: Cpu, desc: "High-density logic enclosures featuring redundant processing and fail-safe I/O architectures for Industry 5.0 autonomy." },
    { title: "VFD & Drive Panels", icon: Zap, desc: "Thermal-optimized power distribution for precision AC/DC speed and torque control with real-time telemetry." },
    { title: "PCC & MCC Panels", icon: Layers, desc: "Industrial-grade Power and Motor Control Centers with intelligent protection and UNS data mobility." },
    { title: "Instrumentation Enclosures", icon: Activity, desc: "Shielded terminal boxes for high-fidelity signal extraction in harsh EMI industrial environments." }
  ];

  return (
    <div className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20 animate-in fade-in slide-in-from-bottom duration-700">
          <div className="flex items-center gap-2 text-emerald-500 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">
            <Ruler className="w-4 h-4" /> INFRASTRUCTURE_PROTOCOL_V4.0
          </div>
          <h1 className="text-4xl md:text-7xl font-bold text-white mb-8 leading-tight">
            Control Panel <span className="text-emerald-500">Engineering</span>
          </h1>
          <p className="text-gray-400 max-w-3xl text-xl leading-relaxed font-light">
            SGA Industrial Automations designs and manufactures premium control panels that serve as the physical foundation for 
            <span className="text-white"> deterministic control</span>. Engineered in Hyderabad for global standards, our enclosures provide 
            unrivaled protection for your <span className="text-emerald-500">Industry 5.0</span> logic.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-32">
          <div className="space-y-8">
            <div className="glass-panel p-10 rounded-[2.5rem] border-l-4 border-l-emerald-500 bg-gradient-to-br from-emerald-950/20 to-transparent">
              <h3 className="text-2xl font-bold text-white mb-6 uppercase tracking-tight">The SGA Build Standard</h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-8">
                Our panels are high-performance environments designed for 24/7 reliability. Every build is a node in your <span className="text-white font-bold">Unified Namespace (UNS)</span> strategy.
              </p>
              <ul className="grid sm:grid-cols-2 gap-6">
                {[
                  "EMI/RFI Shielding", "Smart Thermal Management", "IEC 61439 Compliance",
                  "Arc Flash Protection", "Laser Ferruling", "Deterministic Layouts"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-[10px] font-mono text-emerald-400 uppercase tracking-widest">
                    <ShieldCheck className="w-4 h-4 text-emerald-500" /> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="relative group">
            <div className="absolute -inset-4 bg-emerald-500/10 blur-3xl rounded-full opacity-50 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative glass-panel aspect-square md:aspect-video rounded-[3rem] overflow-hidden flex items-center justify-center p-2">
              <img 
                src="https://www.swastikautomation.com/assets/images/automation-product/industrial-control-panels.jpg" 
                alt="Control Panel Engineering"
                className="w-full h-full object-cover rounded-[2.8rem] opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-[2s]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
              <div className="absolute bottom-10 left-10">
                <div className="text-[10px] font-mono text-emerald-500 tracking-widest bg-black/80 backdrop-blur-md px-6 py-3 rounded-full border border-emerald-500/30 shadow-2xl">
                  ASSET_ID: CP_HYD_PRO_2024
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-32">
          {panelFeatures.map((feature, idx) => (
            <div key={idx} className="group glass-panel p-10 rounded-[2rem] hover:border-emerald-500/50 transition-all duration-500 flex flex-col bg-white/[0.02]">
              <div className="w-14 h-14 bg-emerald-950/40 rounded-2xl flex items-center justify-center border border-emerald-500/30 mb-8 group-hover:scale-110 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                <feature.icon className="text-emerald-500 w-7 h-7 group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold text-white mb-4 uppercase tracking-tighter">{feature.title}</h4>
              <p className="text-gray-500 text-sm leading-relaxed font-light">{feature.desc}</p>
            </div>
          ))}
        </div>

        <div className="relative glass-panel rounded-[3rem] overflow-hidden p-12 md:p-20 text-center border-emerald-500/20 shadow-[0_0_100px_rgba(16,185,129,0.1)]">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent"></div>
          <h3 className="text-3xl md:text-5xl font-bold text-white mb-8">Need a Custom Enclosure?</h3>
          <p className="text-gray-400 max-w-2xl mx-auto mb-12 text-lg font-light leading-relaxed">
            Our Hyderabad Center of Excellence specializes in rapid prototyping and high-volume deployment for <span className="text-white">OT/IT Convergence</span>. 
            All builds undergo rigorous dielectric and functional validation.
          </p>
          <a href="#/contact" className="inline-flex items-center gap-4 px-12 py-5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl transition-all shadow-[0_0_40px_rgba(16,185,129,0.3)] hover:scale-105 group">
            REQUEST PANEL QUOTATION <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default ControlPanels;
