
import React from 'react';
import { Binary, Code, Database, Globe, Network, Terminal, ShieldCheck, Activity, ArrowRight } from 'lucide-react';

const Programming: React.FC = () => {
  const codeDomains = [
    { title: "PLC/DCS Logic", icon: Terminal, desc: "Deterministic control code following IEC 61131-3 standards (LD, ST, FBD) for mission-critical industrial processes." },
    { title: "HMI/SCADA Design", icon: Globe, desc: "High-performance visualization layers designed for cognitive efficiency and deep telemetry visualization." },
    { title: "UNS Integration", icon: Network, desc: "MQTT Sparkplug B architecture to unify your enterprise data into a single, mobile source of truth." },
    { title: "Edge Analytics", icon: Activity, desc: "Custom scripting for predictive maintenance and real-time OEE optimization at the compute edge." }
  ];

  return (
    <div className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20 animate-in fade-in slide-in-from-bottom duration-700">
          <div className="flex items-center gap-2 text-sky-500 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">
            <Code className="w-4 h-4" /> LOGIC_PROTOCOL_V9.2
          </div>
          <h1 className="text-4xl md:text-7xl font-bold text-white mb-8 leading-tight">
            Industrial <span className="text-sky-500">Programming</span>
          </h1>
          <p className="text-gray-400 max-w-3xl text-xl leading-relaxed font-light">
            Logic is the nervous system of the modern factory. SGA Industrial Automations develops 
            <span className="text-white"> deterministic software architectures</span> that bridge field devices 
            and enterprise intelligence using the <span className="text-sky-500 font-bold">Unified Namespace (UNS)</span>.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 xl:grid-cols-4 gap-8 mb-32">
          {codeDomains.map((domain, idx) => (
            <div key={idx} className="glass-panel p-10 rounded-[2rem] group border-t-2 border-t-sky-500/20 hover:border-t-sky-500 transition-all duration-500 flex flex-col bg-white/[0.01]">
              <div className="w-14 h-14 bg-sky-950/40 rounded-xl flex items-center justify-center border border-sky-500/30 mb-8 group-hover:scale-110 group-hover:bg-sky-500 transition-all">
                <domain.icon className="text-sky-400 w-7 h-7 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-xl font-bold text-white mb-4 uppercase tracking-tight">{domain.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed font-light mb-6 flex-grow">{domain.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-16 mb-32">
          <div className="glass-panel p-12 rounded-[3rem] bg-gradient-to-br from-sky-950/20 to-transparent border-sky-500/20">
            <h3 className="text-2xl font-bold text-white mb-10 flex items-center gap-3">
              <Binary className="text-sky-500" /> Programming Standards
            </h3>
            <div className="space-y-6">
              {[
                { label: "Logic Compliance", val: "IEC 61131-3 (ST, LD, FBD)" },
                { label: "Safety Logic", val: "SIL-3 Rated Code Validation" },
                { label: "Data Mobility", val: "MQTT / Sparkplug B / OPC-UA" },
                { label: "HMI Standard", val: "ISA 101 High-Performance" }
              ].map((s, i) => (
                <div key={i} className="flex justify-between items-center border-b border-white/5 pb-6 last:border-0 last:pb-0">
                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">{s.label}</span>
                  <span className="text-sky-400 font-mono text-sm font-bold">{s.val}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex flex-col justify-center space-y-10">
            <div className="flex gap-8 items-start">
              <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/30 flex-shrink-0">
                <ShieldCheck className="text-emerald-500 w-7 h-7" />
              </div>
              <div>
                <h4 className="text-white font-bold mb-3 uppercase tracking-widest text-sm">GAMP 5 Validation</h4>
                <p className="text-gray-400 text-sm leading-relaxed font-light">Specialized software validation for the pharmaceutical sector, ensuring full compliance with <span className="text-white">21 CFR Part 11</span> electronic records and audit trails.</p>
              </div>
            </div>
            <div className="flex gap-8 items-start">
              <div className="p-4 bg-sky-500/10 rounded-2xl border border-sky-500/30 flex-shrink-0">
                <Terminal className="text-sky-400 w-7 h-7" />
              </div>
              <div>
                <h4 className="text-white font-bold mb-3 uppercase tracking-widest text-sm">Deterministic execution</h4>
                <p className="text-gray-400 text-sm leading-relaxed font-light">Our logic is architected for cycle-accurate execution, preventing jitter and ensuring process stability in <span className="text-white">high-speed motion</span> applications.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center relative py-12">
          <div className="absolute top-1/2 left-0 w-full h-px bg-white/5 -z-10"></div>
          <a href="#/contact" className="inline-flex items-center gap-4 px-12 py-5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-2xl transition-all shadow-[0_0_50px_rgba(14,165,233,0.3)] group hover:scale-105">
            INITIATE LOGIC AUDIT <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Programming;
