
import React from 'react';
import { Cpu, Network, Monitor, TrendingUp, CheckCircle2 } from 'lucide-react';

const pillars = [
  {
    title: "Automation (OT)",
    icon: Cpu,
    points: ["PLC / DCS Programming", "Safety Instrumented Systems (SIS)", "High-Precision Motion Control", "Bespoke Control Panels"],
    description: "The core deterministic logic layer of your enterprise."
  },
  {
    title: "Digitalization (IT)",
    icon: Network,
    points: ["Unified Namespace (UNS)", "MQTT Sparkplug B Architecture", "IIoT Edge Gateway Deployment", "IT/OT Convergence Strategy"],
    description: "Architecting the highway for enterprise-wide data mobility."
  },
  {
    title: "Visualization",
    icon: Monitor,
    points: ["High-Performance HMI Design", "Digital Twin Engineering", "Enterprise Data Dashboards", "SCADA Modernization"],
    description: "Contextualizing telemetry into actionable intelligence."
  },
  {
    title: "Optimization",
    icon: TrendingUp,
    points: ["Predictive Maintenance (PdM)", "Energy Management (EMS)", "Advanced Process Control (APC)", "OEE Analytics Integration"],
    description: "Exacting maximum value from every millisecond of operation."
  }
];

const Services: React.FC = () => {
  return (
    <div className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-sky-500 font-mono text-sm tracking-[0.4em] mb-4">CORE_CAPABILITIES</h2>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-8">The Four Pillars</h1>
          <p className="text-gray-400 max-w-3xl mx-auto text-lg leading-relaxed">
            Our engineering rigor extends across the entire lifecycle of industrial maturity, from the physical sensor to the executive dashboard.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {pillars.map((pillar, idx) => (
            <div key={idx} className="glass-panel p-10 rounded-3xl border-l-4 border-l-sky-500 group">
              <div className="flex items-start gap-8">
                <div className="w-16 h-16 bg-sky-900/40 rounded-2xl flex-shrink-0 flex items-center justify-center border border-sky-400/30 group-hover:scale-110 transition-transform">
                  <pillar.icon className="text-sky-400 w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">{pillar.title}</h3>
                  <p className="text-sky-500 font-mono text-xs uppercase tracking-widest mb-6">{pillar.description}</p>
                  
                  <ul className="grid sm:grid-cols-2 gap-4">
                    {pillar.points.map((point, i) => (
                      <li key={i} className="flex items-center gap-3 text-gray-300 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 p-12 glass-panel rounded-3xl text-center border-emerald-500/20">
          <h3 className="text-2xl font-bold text-white mb-4">Ready for a Technical Audit?</h3>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Our engineers will perform a deep-dive analysis of your current OT/IT landscape and provide a deterministic roadmap for Industry 5.0 migration.
          </p>
          <a href="#/contact" className="inline-block px-10 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)]">
            INITIATE SYSTEM ANALYSIS
          </a>
        </div>
      </div>
    </div>
  );
};

export default Services;
