
import React from 'react';
import { Sprout, HardHat, Pill, Zap, ShoppingCart } from 'lucide-react';

const sectors = [
  {
    title: "Agriculture",
    icon: Sprout,
    description: "Precision fertigation & automated harvesting systems designed for high-yield throughput.",
    metrics: "25% Water Savings",
    keywords: ["Precision Ag", "IoT Sensors", "Hydraulic Control"]
  },
  {
    title: "Mining",
    icon: HardHat,
    description: "SIL-rated safety instrumented systems and autonomous ore conveyance logic.",
    metrics: "40% Safety Uptime",
    keywords: ["Hazardous Zones", "Remote Ops", "Telemetry"]
  },
  {
    title: "Pharma",
    icon: Pill,
    description: "GAMP 5 compliant batch management and 21 CFR Part 11 electronic record integrity.",
    metrics: "Zero Compliance Flaws",
    keywords: ["Validated Systems", "Batch Processing", "Clean Room OT"]
  },
  {
    title: "Energy",
    icon: Zap,
    description: "Grid-synchronization and distributed energy resource management (DERMS).",
    metrics: "15% Grid Efficiency",
    keywords: ["Smart Grid", "Substation Automation", "Renewables"]
  },
  {
    title: "FMCG",
    icon: ShoppingCart,
    description: "High-speed packaging lines with integrated OEE visualization and machine vision.",
    metrics: "90% First-Pass Yield",
    keywords: ["Line Control", "Packaging Automation", "Labeling"]
  }
];

const Expertise: React.FC = () => {
  return (
    <div className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <h2 className="text-sky-500 font-mono text-sm tracking-[0.4em] mb-4">SECTOR_SPECIFIC_LOGIC</h2>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Industry Mastery</h1>
          <p className="text-gray-400 max-w-2xl">
            We don't just deploy hardware; we architect vertical-specific solutions that respect the unique constraints of your operational environment.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sectors.map((sector, idx) => (
            <div 
              key={idx} 
              className="group glass-panel rounded-2xl p-8 hover:border-sky-500/50 transition-all duration-500 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <sector.icon size={120} />
              </div>
              
              <div className="w-12 h-12 bg-sky-900/40 rounded-lg flex items-center justify-center border border-sky-400/30 mb-6">
                <sector.icon className="text-sky-400 w-6 h-6" />
              </div>

              <h3 className="text-xl font-bold text-white mb-4">{sector.title}</h3>
              <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                {sector.description}
              </p>

              <div className="space-y-4">
                <div className="bg-sky-500/5 border border-sky-500/20 rounded-lg px-4 py-2">
                  <div className="text-[10px] text-sky-500 font-mono tracking-widest uppercase">Performance Metric</div>
                  <div className="text-white font-bold">{sector.metrics}</div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {sector.keywords.map((kw, i) => (
                    <span key={i} className="text-[9px] font-mono px-2 py-1 bg-white/5 border border-white/10 text-gray-500 uppercase rounded">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Expertise;
