
import React, { useState } from 'react';
import { Send, MapPin, Phone, ShieldCheck, Wifi } from 'lucide-react';

const Contact: React.FC = () => {
  const [encryptionStatus, setEncryptionStatus] = useState("AES-256 BIT READY");

  return (
    <div className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16">
          <div className="space-y-8">
            <div>
              <h2 className="text-sky-500 font-mono text-sm tracking-[0.4em] mb-4">CONNECT_ESTABLISH</h2>
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Secure Data Terminal</h1>
              <p className="text-gray-400 max-w-md">
                Initiate a project consultation or request a technical audit via our encrypted terminal. All submissions are processed through our Hyderabad HQ.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4 p-6 glass-panel rounded-2xl border-l-4 border-l-sky-500">
                <MapPin className="text-sky-400 w-6 h-6 mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-1">Hyderabad HQ</h4>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Level 8, Industrial Automation Hub,<br />
                    Hitech City, Hyderabad, India - 500081
                  </p>
                  <p className="text-sky-500 text-[10px] font-mono mt-2">COORD: 17.4483° N, 78.3915° E</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-6 glass-panel rounded-2xl">
                <Phone className="text-sky-400 w-6 h-6" />
                <div>
                  <h4 className="text-white font-bold mb-1">Signal Channel</h4>
                  <p className="text-gray-400 text-sm leading-relaxed">+91 40 2311 XXXX</p>
                </div>
              </div>

              <div className="p-6 glass-panel rounded-2xl bg-sky-950/20 border border-sky-500/30 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Wifi className="text-emerald-500 w-5 h-5 animate-pulse" />
                  <span className="text-xs font-mono text-emerald-500 uppercase">Signal Strength: Optimal</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="text-sky-500 w-4 h-4" />
                  <span className="text-[10px] font-mono text-sky-500">{encryptionStatus}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-panel p-8 rounded-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
            </div>
            
            <form className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-mono text-sky-500 uppercase tracking-widest">Input: Full_Name</label>
                <input 
                  type="text" 
                  placeholder="ENGINEER NAME" 
                  className="w-full bg-black/40 border border-sky-900/50 rounded-lg px-4 py-3 text-white placeholder:text-gray-700 focus:border-sky-500 focus:outline-none transition-colors font-mono text-sm"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono text-sky-500 uppercase tracking-widest">Input: Enterprise_Mail</label>
                <input 
                  type="email" 
                  placeholder="ADDR@DOMAIN.COM" 
                  className="w-full bg-black/40 border border-sky-900/50 rounded-lg px-4 py-3 text-white placeholder:text-gray-700 focus:border-sky-500 focus:outline-none transition-colors font-mono text-sm"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono text-sky-500 uppercase tracking-widest">Select: Operational_Domain</label>
                <select className="w-full bg-black/40 border border-sky-900/50 rounded-lg px-4 py-3 text-white focus:border-sky-500 focus:outline-none transition-colors font-mono text-sm">
                  <option value="agri">AGRICULTURE</option>
                  <option value="mining">MINING</option>
                  <option value="pharma">PHARMA</option>
                  <option value="energy">ENERGY</option>
                  <option value="fmcg">FMCG</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono text-sky-500 uppercase tracking-widest">Payload: Project_Description</label>
                <textarea 
                  rows={4}
                  placeholder="DEFINE ARCHITECTURAL REQUIREMENTS..." 
                  className="w-full bg-black/40 border border-sky-900/50 rounded-lg px-4 py-3 text-white placeholder:text-gray-700 focus:border-sky-500 focus:outline-none transition-colors font-mono text-sm"
                ></textarea>
              </div>

              <button 
                type="submit" 
                className="w-full py-4 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(14,165,233,0.3)]"
                onClick={(e) => {
                  e.preventDefault();
                  setEncryptionStatus("TRANSMITTING PAYLOAD...");
                  setTimeout(() => setEncryptionStatus("PAYLOAD DELIVERED"), 2000);
                }}
              >
                TRANSMIT DATA <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
