
import React from 'react';
import { Package, ArrowRight } from 'lucide-react';

export const productsList = [
  {
    id: "plc-dcs-systems",
    name: "PLC & DCS Systems",
    brand: "SGA Optimized Hardware",
    image: "https://www.swastikautomation.com/assets/images/automation-product/plc-dcs-systems.jpg",
    shortDesc: "High-integrity deterministic control engines engineered for seamless Industry 5.0 autonomy and real-time logic execution.",
    description: "Our PLC and DCS solutions represent the pinnacle of deterministic control, acting as the high-availability core for modern industrial infrastructure. Engineered for the Industry 5.0 era, these systems facilitate total OT/IT Convergence by bridging physical field signals with high-level enterprise logic. By adopting a Unified Namespace (UNS) approach, our controllers ensure your facility operates with unparalleled engineering rigor, providing a robust foundation for predictive maintenance and zero-latency execution across complex manufacturing environments.",
    tags: ["IEC 61131-3", "SIL-Rated", "Deterministic Logic"],
    specs: {
      "Processing Speed": "0.1ms/1k instructions",
      "Network Protocol": "Profinet, EtherCAT, MQTT Sparkplug B",
      "Safety Rating": "SIL 3 Certified",
      "Redundancy": "Hardware & Software supported"
    }
  },
  {
    id: "ac-dc-drives",
    name: "AC/DC Drive Solutions",
    brand: "Precision Motion",
    image: "https://www.swastikautomation.com/assets/images/automation-product/ac-dc-drive.jpg",
    shortDesc: "Premium motion controllers optimized for energy efficiency and Unified Namespace (UNS) reporting via Sparkplug B.",
    description: "SGA's AC/DC Drive Solutions provide the mechanical finesse required for high-speed industrial operations while maintaining strict energy management standards. These drives are built to feed real-time energy telemetry directly into your Unified Namespace (UNS), allowing for enterprise-wide visualization of motor health and consumption. Through advanced SCADA integration, facilities achieve precise torque control and a significant reduction in operational carbon footprint, making them essential for sustainable Industry 5.0 transitions.",
    tags: ["Energy Management", "UNS Mobility", "VFD"],
    specs: {
      "Power Range": "0.4kW - 1.2MW",
      "Control Mode": "Sensorless Vector, Flux Control",
      "Efficiency": ">98% at Rated Load",
      "Interface": "Modbus TCP, EtherNet/IP"
    }
  },
  {
    id: "servo-drive-motors",
    name: "Servo Drive & Motors",
    brand: "Elite Motion",
    image: "https://www.swastikautomation.com/assets/images/automation-product/servo-drive-motors.jpg",
    shortDesc: "Ultra-precise robotic actuators enabling the human-centric focus and agility of the Industry 5.0 landscape.",
    description: "Our elite Servo systems deliver micro-millimeter positioning accuracy, essential for the high-dynamic robotics and intricate assembly tasks of Industry 5.0. These motors empower flexible manufacturing through deterministic control actuators that ensure every movement is validated and repeatable. By integrating directly with edge computing gateways, they provide the granular data necessary for advanced predictive maintenance, ensuring your robotic assets maintain peak performance with minimal downtime.",
    tags: ["Robotics", "Positioning", "Industry 5.0"],
    specs: {
      "Resolution": "24-bit Absolute Encoder",
      "Peak Torque": "300% of Rated Torque",
      "Response Time": "<1ms Positioning loop",
      "Compliance": "CE, UL, RoHS"
    }
  },
  {
    id: "hmi-systems",
    name: "Human Machine Interface (HMI)",
    brand: "SGA Visual Core",
    image: "https://www.swastikautomation.com/assets/images/automation-product/human-machine-interface.jpg",
    shortDesc: "High-fidelity visualization terminals designed for the modern OT/IT command center and digital twin interaction.",
    description: "SGA Visual Core HMIs transform raw industrial telemetry into actionable intelligence through high-performance glassmorphism interfaces. Designed as the primary node for OT/IT Convergence, our HMI systems provide operators with clear, real-time insights into complex process variables flowing through the Unified Namespace (UNS). These terminals are the tactile edge of your Industry 5.0 strategy, ensuring that human-in-the-loop decisions are backed by precise, deterministic data visualization and seamless SCADA integration.",
    tags: ["Visualization", "OT/IT Bridge", "Edge Computing"],
    specs: {
      "Display": "10.1\" - 24\" High Definition",
      "Processor": "Quad-Core Cortex-A53",
      "OS": "Linux RTOS / Windows IoT",
      "Protection": "NEMA 4X / IP66"
    }
  }
];

const Products: React.FC = () => {
  return (
    <div className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20 animate-in fade-in slide-in-from-bottom duration-700">
          <h2 className="text-emerald-500 font-mono text-sm tracking-[0.4em] mb-4 uppercase">System_Inventory</h2>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-8">Industrial Control Assets</h1>
          <p className="text-gray-400 max-w-3xl text-lg leading-relaxed">
            SGA delivers elite automation assets. Every system is engineered for <span className="text-white font-semibold">deterministic control</span> and native compatibility with <span className="text-emerald-500 font-bold italic underline decoration-emerald-500/30">Unified Namespace (UNS)</span> protocols.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {productsList.map((product, idx) => (
            <div 
              key={product.id} 
              className="glass-panel rounded-3xl overflow-hidden group hover:border-emerald-500/50 transition-all duration-500 flex flex-col transform hover:-translate-y-2"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <div className="relative h-64 overflow-hidden bg-black/50">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-95 group-hover:scale-110 transition-all duration-1000"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800";
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                <div className="absolute bottom-4 left-4">
                  <span className="text-[10px] font-mono bg-emerald-600/80 backdrop-blur-sm text-white px-3 py-1 rounded-full uppercase tracking-widest shadow-lg border border-white/10">
                    {product.brand}
                  </span>
                </div>
              </div>

              <div className="p-8 flex-grow flex flex-col">
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-emerald-400 transition-colors">
                  {product.name}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-6 flex-grow">
                  {product.shortDesc}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-8">
                  {product.tags.map((tag, i) => (
                    <span key={i} className="text-[9px] font-mono border border-emerald-500/20 bg-emerald-500/5 text-emerald-400 px-2 py-1 rounded uppercase">
                      {tag}
                    </span>
                  ))}
                </div>

                <a 
                  href={`#/products/${product.id}`} 
                  className="w-full py-4 bg-emerald-900/20 border border-emerald-500/30 rounded-xl text-center text-xs font-mono text-emerald-400 hover:bg-emerald-600 hover:text-white hover:border-emerald-400 transition-all tracking-widest flex items-center justify-center gap-2 group/btn"
                >
                  ACCESS_DETAILED_SPECS <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Products;
