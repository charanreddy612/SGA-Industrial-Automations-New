
import React from 'react';
import { ArrowUpRight, Cog, Zap, Package, Activity, ArrowRight, Binary, Cpu, ShieldCheck, Database } from 'lucide-react';
import { productsList } from './Products';

const Home: React.FC = () => {
  // Curated selection of 3 flagship products for the spotlight section
  const spotlightProducts = productsList.slice(0, 3);

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-in fade-in slide-in-from-left duration-1000">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-mono">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                SGA TERMINAL: ENCRYPTED_LINK_ACTIVE
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white leading-tight">
                Architecting <span className="text-emerald-500">Industrial</span> Intelligence.
              </h1>
              
              <p className="text-lg text-gray-400 max-w-xl leading-relaxed">
                Hyderabad's premier Industry 5.0 integrator. We unify legacy infrastructure with deterministic UNS architecture to drive +35% OEE growth.
              </p>

              <div className="flex flex-wrap gap-4">
                <a href="#/services" className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.4)] uppercase text-sm tracking-widest">
                  EXPLORE PILLARS <ArrowUpRight className="w-5 h-5" />
                </a>
                <a href="#/products" className="px-8 py-4 glass-panel text-white font-bold rounded-lg hover:bg-white/5 transition-all uppercase text-sm tracking-widest">
                  VIEW SYSTEMS
                </a>
              </div>

              <div className="grid grid-cols-3 gap-8 pt-8 border-t border-emerald-900/30">
                <div>
                  <div className="text-2xl font-bold text-white font-mono">35%<span className="text-emerald-500">+</span></div>
                  <div className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">OEE Gain</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white font-mono">20%<span className="text-emerald-500">-</span></div>
                  <div className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">Energy Usage</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white font-mono">500<span className="text-emerald-500">+</span></div>
                  <div className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">Deployments</div>
                </div>
              </div>
            </div>

            <div className="relative hidden lg:block">
              <div className="relative w-full h-[500px] glass-panel rounded-3xl overflow-hidden p-8 flex items-center justify-center">
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                  <svg className="w-full h-full" viewBox="0 0 400 400">
                    <circle cx="200" cy="200" r="150" fill="none" stroke="#10b981" strokeWidth="1" strokeDasharray="5 5" className="animate-[spin_60s_linear_infinite]" />
                    <circle cx="200" cy="200" r="100" fill="none" stroke="#10b981" strokeWidth="2" strokeDasharray="10 10" className="animate-[spin_30s_linear_infinite_reverse]" />
                    <path d="M200 50 L200 350 M50 200 L350 200" stroke="#10b981" strokeWidth="0.5" opacity="0.3" />
                  </svg>
                </div>
                
                <div className="z-10 text-center space-y-4">
                  <div className="w-24 h-24 bg-emerald-500/20 border border-emerald-400/50 rounded-2xl mx-auto flex items-center justify-center animate-pulse">
                    <Cog className="w-12 h-12 text-emerald-400 animate-[spin_10s_linear_infinite]" />
                  </div>
                  <div className="font-mono text-xs text-emerald-400 tracking-[0.3em]">TELEMETRY_LINK_STABLE</div>
                  <div className="text-white text-sm font-mono uppercase">Unified Namespace: Active</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Flagship Control Solutions - Spotlight Section */}
      <section className="py-24 px-6 bg-gradient-to-b from-transparent via-emerald-950/5 to-transparent relative overflow-hidden">
        {/* Background Decorative Grid */}
        <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none"></div>
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent"></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col lg:flex-row justify-between items-end mb-16 gap-8">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2 text-emerald-500 font-mono text-[10px] tracking-[0.5em] uppercase mb-4">
                <Database className="w-4 h-4" /> SGA_SYSTEM_SPOTLIGHT_V3.0
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">Flagship Control Solutions</h2>
              <p className="text-gray-400 text-lg font-light leading-relaxed">
                A deterministic selection of our high-integrity assets, engineered for 
                <span className="text-white"> OT/IT Convergence</span> and 
                <span className="text-emerald-500"> Industry 5.0</span> resilience.
              </p>
            </div>
            <a 
              href="#/products" 
              className="group flex items-center gap-3 text-emerald-500 font-mono text-[10px] tracking-widest uppercase border-b border-emerald-500/20 pb-2 hover:text-white hover:border-white transition-all duration-300"
            >
              Access_Complete_Systems_Index <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {spotlightProducts.map((product, idx) => (
              <div 
                key={product.id}
                className="group relative glass-panel rounded-[2.5rem] overflow-hidden flex flex-col transition-all duration-700 hover:border-emerald-500/50 hover:shadow-[0_20px_60px_-15px_rgba(16,185,129,0.2)] transform hover:-translate-y-3"
              >
                {/* Product Image Wrapper */}
                <div className="relative h-64 overflow-hidden bg-black/40">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover opacity-40 group-hover:opacity-80 group-hover:scale-110 transition-all duration-[1.5s]"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800";
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#010409] via-[#010409]/20 to-transparent"></div>
                  
                  {/* Floating UI Elements */}
                  <div className="absolute top-6 left-6 flex flex-col gap-2">
                    <span className="px-3 py-1 bg-emerald-500/10 backdrop-blur-md border border-emerald-500/30 rounded-full text-[8px] font-mono text-emerald-400 uppercase tracking-widest">
                      {product.brand}
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-8 right-8">
                     <h3 className="text-2xl font-bold text-white group-hover:text-emerald-400 transition-colors duration-300">
                       {product.name}
                     </h3>
                  </div>
                </div>

                {/* Content Area */}
                <div className="p-8 pt-6 flex flex-col flex-grow bg-gradient-to-b from-[#010409] to-black">
                  <p className="text-gray-400 text-sm leading-relaxed mb-8 font-light line-clamp-2 italic">
                    {product.shortDesc}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="flex items-center gap-2 text-[9px] font-mono text-gray-500 uppercase tracking-tighter">
                      <Cpu className="w-3 h-3 text-emerald-600" /> UNS_COMPATIBLE
                    </div>
                    <div className="flex items-center gap-2 text-[9px] font-mono text-gray-500 uppercase tracking-tighter">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" /> SIL_VALIDATED
                    </div>
                  </div>

                  <div className="mt-auto">
                    <a 
                      href={`#/products/${product.id}`}
                      className="group/btn w-full py-4 bg-emerald-950/30 border border-emerald-500/20 rounded-2xl flex items-center justify-center gap-3 text-[10px] font-mono font-bold text-emerald-500 hover:bg-emerald-600 hover:text-white hover:border-emerald-400 transition-all duration-300 tracking-[0.2em] uppercase"
                    >
                      Initialize_Fetch <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                    </a>
                  </div>
                </div>
                
                {/* Decorative scanning line (visible on hover) */}
                <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500/0 group-hover:bg-emerald-500/50 group-hover:animate-pulse transition-all"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LIVE CTA Section */}
      <section className="py-24 px-6 relative">
        <div className="max-w-4xl mx-auto glass-panel p-1 border-emerald-500/20 rounded-[3rem] shadow-[0_0_80px_rgba(16,185,129,0.1)]">
          <div className="bg-emerald-950/10 rounded-[2.8rem] p-12 md:p-16 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent"></div>
            
            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[9px] font-mono tracking-widest uppercase mb-8">
                Deployment_Protocol_Ready
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Ignite Your Industry 5.0 Evolution</h2>
              <p className="text-gray-400 mb-12 text-lg max-w-2xl mx-auto leading-relaxed">
                Partner with our engineering elite to perform a <span className="text-emerald-400 font-bold">Deterministic Performance Audit</span>. Bridge your legacy systems to a secure, data-mobile future.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <a 
                  href="#/contact" 
                  className="group relative px-10 py-5 bg-emerald-600 rounded-2xl font-bold text-white overflow-hidden shadow-[0_0_40px_rgba(16,185,129,0.3)] hover:scale-105 transition-all duration-500"
                >
                  <span className="relative z-20 flex items-center justify-center gap-3 tracking-[0.1em] text-sm uppercase">
                    INITIATE LIVE AUDIT <Zap className="w-5 h-5 fill-current" />
                  </span>
                  <div className="absolute inset-0 bg-white/10 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>
                </a>
                <a 
                  href="#/about" 
                  className="px-10 py-5 glass-panel rounded-2xl font-bold text-white border-white/5 hover:bg-white/10 transition-all duration-300 text-sm tracking-[0.1em] uppercase"
                >
                  ENGINEERING_METHODOLOGY
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Keywords Ticker */}
      <div className="bg-black/80 border-y border-emerald-900/20 py-6 overflow-hidden whitespace-nowrap relative">
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#010409] to-transparent z-10"></div>
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#010409] to-transparent z-10"></div>
        
        <div className="inline-block animate-[scroll_40s_linear_infinite]">
          {[
            "MQTT SPARKPLUG B", "UNIFIED NAMESPACE (UNS)", "PLC LOGIC", "SCADA INTEGRATION", 
            "OEE ANALYTICS", "PREDICTIVE MAINTENANCE", "IEC 62443", "GAMP 5", 
            "OT/IT CONVERGENCE", "HYDERABAD INDUSTRIAL AUTOMATION", "DETERMINISTIC CONTROL"
          ].map((kw, i) => (
            <span key={i} className="mx-12 text-[10px] font-mono text-emerald-800 uppercase tracking-[0.4em] font-bold">{kw}</span>
          ))}
          {/* Duplicate for seamless scrolling */}
          {[
            "MQTT SPARKPLUG B", "UNIFIED NAMESPACE (UNS)", "PLC LOGIC", "SCADA INTEGRATION", 
            "OEE ANALYTICS", "PREDICTIVE MAINTENANCE", "IEC 62443", "GAMP 5", 
            "OT/IT CONVERGENCE", "HYDERABAD INDUSTRIAL AUTOMATION", "DETERMINISTIC CONTROL"
          ].map((kw, i) => (
            <span key={`dup-${i}`} className="mx-12 text-[10px] font-mono text-emerald-800 uppercase tracking-[0.4em] font-bold">{kw}</span>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
};

export default Home;
