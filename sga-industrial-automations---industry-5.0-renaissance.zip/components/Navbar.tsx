
import React, { useState } from 'react';
import { Activity, ShieldCheck, Database, LayoutDashboard, Mail, Package, ChevronDown } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
}

const Navbar: React.FC<NavbarProps> = ({ currentPath }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const navItems = [
    { name: 'COMMAND', path: '#/', icon: LayoutDashboard },
    { name: 'RIGOR', path: '#/about', icon: ShieldCheck },
    { name: 'DOMAINS', path: '#/expertise', icon: Activity },
    { 
      name: 'PILLARS', 
      path: '#/services', 
      icon: Database,
      hasDropdown: true,
      subItems: [
        { name: 'General Overview', path: '#/services' },
        { name: 'Control Panel Engineering', path: '#/services/control-panels' },
        { name: 'Industrial Programming', path: '#/services/programming' },
      ]
    },
    { name: 'SYSTEMS', path: '#/products', icon: Package },
    { name: 'TERMINAL', path: '#/contact', icon: Mail },
  ];

  return (
    <nav className="sticky top-0 z-50 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between glass-panel rounded-2xl px-6 py-2">
        <div className="flex items-center gap-4">
          <a href="#/" className="flex items-center gap-4 group">
            <div className="relative">
              <svg width="40" height="40" viewBox="0 0 100 100" className="drop-shadow-[0_0_8px_rgba(16,185,129,0.4)]">
                <path 
                  d="M50 10C30 10 15 25 15 45C15 60 25 75 40 85L45 95L55 95L52 88C75 80 85 60 85 45C85 25 70 10 50 10ZM45 25C48 25 50 27 50 30C50 33 48 35 45 35C42 35 40 33 40 30C40 27 42 25 45 25ZM65 45C65 55 55 65 45 65C35 65 25 55 25 45C25 35 35 25 45 25L45 28C38 28 32 34 32 41C32 48 38 54 45 54C52 54 58 48 58 41L61 41C61 50 54 57 45 57C36 57 29 50 29 41C29 32 36 25 45 25L45 22C33 22 22 33 22 45C22 57 33 68 45 68C57 68 68 57 68 45H65Z" 
                  fill="#10b981" 
                  className="animate-pulse"
                />
              </svg>
            </div>
            <div className="h-8 w-[1px] bg-emerald-500/30 hidden sm:block"></div>
            <div className="flex flex-col">
              <span className="font-bold text-xl tracking-tight leading-none text-white flex items-center gap-1">
                SGA <span className="text-emerald-500 font-medium hidden sm:inline">INDUSTRIAL AUTOMATIONS</span>
              </span>
              <span className="text-[9px] font-mono text-gray-500 tracking-[0.3em] uppercase">Industry 5.0 Renaissance</span>
            </div>
          </a>
        </div>

        <div className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <div 
              key={item.path} 
              className="relative group"
              onMouseEnter={() => item.hasDropdown && setIsDropdownOpen(true)}
              onMouseLeave={() => item.hasDropdown && setIsDropdownOpen(false)}
            >
              <a
                href={item.path}
                className={`flex items-center gap-2 text-xs font-mono tracking-widest transition-all duration-300 ${
                  currentPath === item.path ? 'text-emerald-500 neon-text' : 'text-gray-400 hover:text-white'
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
                {item.hasDropdown && <ChevronDown className={`w-3 h-3 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />}
              </a>

              {item.hasDropdown && isDropdownOpen && (
                <div className="absolute top-full left-0 pt-4 w-64 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="glass-panel rounded-xl overflow-hidden shadow-2xl border-emerald-500/30">
                    {item.subItems?.map((sub) => (
                      <a 
                        key={sub.path}
                        href={sub.path}
                        className="block px-6 py-4 text-[10px] font-mono text-gray-400 hover:bg-emerald-500/10 hover:text-emerald-400 border-b border-white/5 last:border-0 transition-colors tracking-widest uppercase"
                      >
                        {sub.name}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <a href="#/contact" className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-mono font-bold py-2 px-4 rounded border border-emerald-400/50 transition-all shadow-[0_0_10px_rgba(16,185,129,0.2)]">
          INITIATE_AUDIT
        </a>
      </div>
    </nav>
  );
};

export default Navbar;
